require 'test_helper'

class OrderNotificationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
