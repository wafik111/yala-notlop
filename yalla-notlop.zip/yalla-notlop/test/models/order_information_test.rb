require 'test_helper'

class OrderInformationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
