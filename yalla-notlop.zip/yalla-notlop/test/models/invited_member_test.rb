require 'test_helper'

class InvitedMemberTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
